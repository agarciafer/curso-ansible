# Red-Hat-Certified-Specialist-in-Services-Management-and-Automation-EX358-ch5
Red Hat Certified Specialist in Services Management and Automation (EX358), Published by Packt
Written by Eric McLeroy
