CREATE TABLE IF NOT EXISTS people (
names varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
INSERT INTO people(names) VALUES('aLBERTO');
INSERT INTO people(names) VALUES('Ana');
INSERT INTO people(names) VALUES('Juan');
